const express = require('express')
const app = express()
const port = 3000
const {getAllCTIAssets, createCTIAsset, readCTIAsset, updateCTIAsset, deleteCTIAsset, assetCTIExists, modifyLOC} = require('./app')

app.get('/', (req, res) => {
    res.send('It is working!')
})

app.get('/api/get-all', async (req, res) => {
    const jsonString = await getAllCTIAssets()
    res.send(jsonString)

})

app.get('/api/create',async (req, res) => {
    if (req.query.id && req.query.timestamp && req.query.loc && req.query.from && req.query.target && req.query.type) {
        const jsonString = await createCTIAsset(req.query.id, req.query.timestamp,req.query.loc, req.query.from, req.query.target, req.query.type);
        res.send(jsonString)
    } else {
        res.send('xxx requested')
    }
})

app.get('/api/update', async (req, res) => {
    if (req.query.id && req.query.timestamp && req.query.loc && req.query.from && req.query.target && req.query.type) {
        await updateCTIAsset(req.query.id, req.query.timestamp,req.query.loc, req.query.from, req.query.target, req.query.type);
        res.send('CTI id = '+req.query.id+' updated')
    } else {
        res.send('xxx requested')
    }
})

app.get('/api/read',async (req, res) => {
    if (req.query.id) {
        const jsonString = await readCTIAsset(req.query.id);
        res.send(jsonString)
    } else {
        res.send('No ID provided! xxxx and xxx requested')
    }
})

app.get('/api/delete', async (req, res) => {
    if (req.query.id) {
        await deleteCTIAsset(req.query.id);
        res.send('CTI id = '+req.query.id+' deleted')
    } else {
        res.send('No ID provided!')
    }
})

app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
})
