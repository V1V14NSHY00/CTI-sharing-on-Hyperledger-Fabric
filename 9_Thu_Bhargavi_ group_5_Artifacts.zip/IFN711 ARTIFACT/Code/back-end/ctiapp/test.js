const {getAllCTIAssets, createCTIAsset, readCTIAsset, updateCTIAsset, deleteCTIAsset, assetCTIExists, modifyLOC} = require('./app');

console.log('getAllCTIAssets')

async function test (){
        const a = await getAllCTIAssets();
        console.log('result is' + a);
        const i = await createCTIAsset('cti7', '1', '2', '3', '4', '5');
        console.log('result is' + i);
        const o = await createCTIAsset('cti8', '1', '2', '3', '4', '5');
        console.log('result is' + o);
        const p = await createCTIAsset('cti9', '1', '2', '3', '4', '5');
        console.log('result is' + p);
        const e = await createCTIAsset('cti4', '1', '2', '3', '4', '5');
        console.log('result is' + e);
        const f = await createCTIAsset('cti5', '1', '2', '3', '4', '5');
        console.log('result is' + f);
        const g = await createCTIAsset('cti6', '1', '2', '3', '4', '5');
        console.log('result is' + g);
}
test();