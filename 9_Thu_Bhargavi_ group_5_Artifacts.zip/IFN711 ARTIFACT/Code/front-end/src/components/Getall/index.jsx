import React, { Component } from 'react'
import {Container, Row, Col} from 'react-bootstrap'
import axios from 'axios'
import {Button} from 'antd'

export default class Getall extends Component {
    getall = ()=>{
        axios.get(`http://localhost:3001/api/get-all`).then(
            response => {
                this.props.saveAllCTIs(response.data)
            },
            error => {console.log('fail',error);}
        )
    }


  render() {
    return (
        <Container>
            <Row>
                <Col><Button type='primary' size='small' onClick={this.getall}>Show all CTIs in the ledger</Button></Col>
            </Row>
        </Container>
    )
  }
}
