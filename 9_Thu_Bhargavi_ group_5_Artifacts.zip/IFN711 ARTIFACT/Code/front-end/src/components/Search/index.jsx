import axios from 'axios'
import React, { Component } from 'react'
import { Button, Input } from 'antd';
const SearchBox ={
    width: '100%',
    display: 'flex',
    paddingBottom: '20px',
    alignItems: 'baseline',
    justifyContent: 'space-between',
}

export default class Search extends Component {
    search = () =>{
        const {keyWordElement:{value:ctiID}} = this
        axios.get(`http://localhost:3001/api/read?id=${ctiID}`).then(
            response => {
                console.log(response.data)
                this.props.saveCTIs(response.data)
            },
            error => {console.log('fail',error);}
        )
    }
    
  render() {
    return (
        <div style={SearchBox}>
            <p  style={{ color:'#333', width: '150px'}}>Search CTI's ID</p>
            {/* <Input ref={c => this.keyWordElement = c} type="text" placeholder="enter CTI's ID here" style={{  marginRight: '10px'}}/> */}
            <input ref={c => this.keyWordElement = c} type="text" placeholder="Enter CTI's ID here" style={{  marginRight: '10px'}}/>&nbsp;
            <Button onClick={this.search} type="primary">Search</Button>            
        </div>
    )
  }
}
