import React, { Component } from 'react'
import {Link} from 'react-router-dom'
// import {Navbar, Nav, Container} from 'react-bootstrap'
const HeaderBox = {
    width: '100%',
    height: '55px',
    background: 'rgba(0,0,0,.6)',
    display: 'flex',
    marginBottom: '20px',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '0 10px',
}
const H1Box = {
  color: '#fff',
  margin: '0',
  padding: '0'
}
export default class Header extends Component {
  render() {
    return (
      // <Navbar
      // bg='light'
      // variant='light'
      // sticky='top'
      // style={{
      //     padding:10
      // }}
      // >
          // <Navbar.Brand href='/'>
          //     <h1
          //     style={{
          //         color:'#cbc3e3',
          //     }}
          //     >CTI sharing</h1>
          //     <b>group name</b>
          // </Navbar.Brand>
          // <Navbar.Collapse
          // className='justify-content-end'>
          //     <h4>CONTECT US</h4>
          // </Navbar.Collapse>

      // </Navbar>
      // <Navbar expand="lg" bg="primary" variant="dark">
      //   <Container>
      //   <Navbar.Brand href='/'>
      //         <h1
      //         style={{
      //             color:'#cbc3e3',
      //         }}
      //         >CTI sharing</h1>
              
      //     </Navbar.Brand>
      //     <Nav className="me-auto">
      //       <Nav.Link href="/">Home</Nav.Link>
      //       <Nav.Link href="/login">Login</Nav.Link>
      //       <Nav.Link href="/">Contact us</Nav.Link>
      //     </Nav>
      //     <Navbar.Collapse bg="primary" variant="dark"
      //       className='justify-content-end'>
      //           The reliable spark plugs
      //       </Navbar.Collapse>
          
      //   </Container>
      // </Navbar>
      <div style={HeaderBox}>
        <h1 style={H1Box}>CTI sharing</h1>
        <div>
          <span><Link to="/" style={{ color:'#fff'}}>home</Link></span>
          <span style={{ color:'#fff',padding: '0 20px'}}>|</span>
          <span><Link to="/login" style={{ color:'#fff'}}>Login</Link></span>
          <span style={{ color:'#fff',padding: '0 20px'}}>|</span>
          <span><Link to="/" style={{ color:'#fff'}}>Contact us</Link></span>
        </div>
        <p style={H1Box}>The reliable spark plugs</p>
      </div>
    )
  }
}
