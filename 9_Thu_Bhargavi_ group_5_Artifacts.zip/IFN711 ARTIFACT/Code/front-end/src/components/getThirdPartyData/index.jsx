import React, { Component } from 'react'
import {Container, Row, Col} from 'react-bootstrap'
import {Button} from 'antd'
import axios from 'axios'
import data from './data'

export default class GetThirdPartyData extends Component {


    getThirdPartyData=()=>{
        data.map((ctiobj)=>{
            axios.get(`http://localhost:3001/api/create?id=${ctiobj.id}&loc=${ctiobj.status}&target=${ctiobj.Description}&timestamp=2022/5/26&type=${ctiobj.weaknessabs}&from=circl`).then(
                response => {
                    console.log(response.data)
                },
                error => {console.log('fail',error);}
            )
        })
    }

    render() {
        return (
            <Container>
                <Row>
                    <Col><Button type='primary' size='small' onClick={this.getThirdPartyData}>Click to add CTIs from CIRCL to ledger</Button></Col>
                </Row>
            </Container>
        )
    }
}
