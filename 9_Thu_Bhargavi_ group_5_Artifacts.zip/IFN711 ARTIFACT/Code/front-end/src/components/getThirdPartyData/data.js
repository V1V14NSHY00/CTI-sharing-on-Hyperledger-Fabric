let data = [
    {
        "Description": "This category has been deprecated. It was originally used for organizing the Development View (CWE-699), but it introduced unnecessary complexity and depth to the resulting tree.This category has been deprecated. It was originally used for organizing the Development View (CWE-699), but it introduced unnecessary complexity and depth to the resulting tree.",
        "id": "1",
        "name": "DEPRECATED: Location",
        "status": "Deprecated",
        "weaknessabs": "Category"
    },
    {
        "Description": "This category represents one of the phyla in the Seven Pernicious Kingdoms vulnerability classification. It includes weaknesses that are typically introduced during unexpected environmental conditions. According to the authors of the Seven Pernicious Kingdoms, \"This section includes everything that is outside of the source code but is still critical to the security of the product that is being created. Because the issues covered by this kingdom are not directly related to source code, we separated it from the rest of the kingdoms.\"This category represents one of the phyla in the Seven Pernicious Kingdoms vulnerability classification. It includes weaknesses that are typically introduced during unexpected environmental conditions. According to the authors of the Seven Pernicious Kingdoms, \"This section includes everything that is outside of the source code but is still critical to the security of the product that is being created. Because the issues covered by this kingdom are not directly related to source code, we separated it from the rest of the kingdoms.\"",
        "id": "2",
        "name": "7PK - Environment",
        "relationships": [],
        "status": "Draft",
        "weaknessabs": "Category"
    },
    {
        "Description": "This category has been deprecated. It was originally intended as a \"catch-all\" for environment issues for technologies that did not have their own CWE, but it introduced unnecessary depth and complexity to the Development View (CWE-699).This category has been deprecated. It was originally intended as a \"catch-all\" for environment issues for technologies that did not have their own CWE, but it introduced unnecessary depth and complexity to the Development View (CWE-699).",
        "id": "3",
        "name": "DEPRECATED: Technology-specific Environment Issues",
        "status": "Deprecated",
        "weaknessabs": "Category"
    },
    {
        "Description": "This entry has been deprecated.  It was originally used for organizing the Development View (CWE-699) and some other views, but it introduced unnecessary complexity and depth to the resulting tree.This entry has been deprecated.  It was originally used for organizing the Development View (CWE-699) and some other views, but it introduced unnecessary complexity and depth to the resulting tree.",
        "id": "4",
        "name": "DEPRECATED: J2EE Environment Issues",
        "status": "Deprecated",
        "weaknessabs": "Category"
    },
    {
        "Description": "The application configuration should ensure that SSL or an encryption mechanism of equivalent strength and vetted reputation is used for all access-controlled pages.The application configuration should ensure that SSL or an encryption mechanism of equivalent strength and vetted reputation is used for all access-controlled pages.",
        "id": "5",
        "name": "J2EE Misconfiguration: Data Transmission Without Encryption",
        "status": "Draft",
        "weaknessabs": "Variant"
    },
    {
        "Description": "A lower bound on the number of valid session identifiers that are available to be guessed is the number of users that are active on a site at any given moment. However, any users that abandon their sessions without logging out will increase this number. (This is one of many good reasons to have a short inactive session timeout.) With a 64 bit session identifier, assume 32 bits of entropy. For a large web site, assume that the attacker can try 1,000 guesses per second and that there are 10,000 valid session identifiers at any given moment. Given these assumptions, the expected time for an attacker to successfully guess a valid session identifier is less than 4 minutes. Now assume a 128 bit session identifier that provides 64 bits of entropy. With a very large web site, an attacker might try 10,000 guesses per second with 100,000 valid session identifiers available to be guessed. Given these assumptions, the expected time for an attacker to successfully guess a valid session identifier is greater than 292 years.A lower bound on the number of valid session identifiers that are available to be guessed is the number of users that are active on a site at any given moment. However, any users that abandon their sessions without logging out will increase this number. (This is one of many good reasons to have a short inactive session timeout.) With a 64 bit session identifier, assume 32 bits of entropy. For a large web site, assume that the attacker can try 1,000 guesses per second and that there are 10,000 valid session identifiers at any given moment. Given these assumptions, the expected time for an attacker to successfully guess a valid session identifier is less than 4 minutes. Now assume a 128 bit session identifier that provides 64 bits of entropy. With a very large web site, an attacker might try 10,000 guesses per second with 100,000 valid session identifiers available to be guessed. Given these assumptions, the expected time for an attacker to successfully guess a valid session identifier is greater than 292 years.",
        "id": "6",
        "name": "J2EE Misconfiguration: Insufficient Session-ID Length",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Verify return values are correct and do not supply sensitive information about the system.Verify return values are correct and do not supply sensitive information about the system.",
        "id": "7",
        "name": "J2EE Misconfiguration: Missing Custom Error Page",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Declare Java beans \"local\" when possible. When a bean must be remotely accessible, make sure that sensitive information is not exposed, and ensure that the application logic performs appropriate validation of any data that might be modified by an attacker.Declare Java beans \"local\" when possible. When a bean must be remotely accessible, make sure that sensitive information is not exposed, and ensure that the application logic performs appropriate validation of any data that might be modified by an attacker.",
        "id": "8",
        "name": "J2EE Misconfiguration: Entity Bean Declared Remote",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Follow the principle of least privilege when assigning access rights to EJB methods. Permission to invoke EJB methods should not be granted to the ANYONE role.Follow the principle of least privilege when assigning access rights to EJB methods. Permission to invoke EJB methods should not be granted to the ANYONE role.",
        "id": "9",
        "name": "J2EE Misconfiguration: Weak Access Permissions for EJB Methods",
        "status": "Draft",
        "weaknessabs": "Variant"
    },
    {
        "Description": "This category has been deprecated. It added unnecessary depth and complexity to its associated views.This category has been deprecated. It added unnecessary depth and complexity to its associated views.",
        "id": "10",
        "name": "DEPRECATED: ASP.NET Environment Issues",
        "status": "Deprecated",
        "weaknessabs": "Category"
    },
    {
        "Description": "Avoid releasing debug binaries into the production environment. Change the debug mode to false when the application is deployed into production.Avoid releasing debug binaries into the production environment. Change the debug mode to false when the application is deployed into production.",
        "id": "11",
        "name": "ASP.NET Misconfiguration: Creating Debug Binary",
        "status": "Draft",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Verify return values are correct and do not supply sensitive information about the system.Verify return values are correct and do not supply sensitive information about the system.",
        "id": "12",
        "name": "ASP.NET Misconfiguration: Missing Custom Error Page",
        "status": "Draft",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Credentials stored in configuration files should be encrypted, Use standard APIs and industry accepted algorithms to encrypt the credentials stored in configuration files.Credentials stored in configuration files should be encrypted, Use standard APIs and industry accepted algorithms to encrypt the credentials stored in configuration files.",
        "id": "13",
        "name": "ASP.NET Misconfiguration: Password in Configuration File",
        "status": "Draft",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Where possible, encrypt sensitive data that are used by a software system.Where possible, encrypt sensitive data that are used by a software system.",
        "id": "14",
        "name": "Compiler Removal of Code to Clear Buffers",
        "status": "Draft",
        "weaknessabs": "Variant"
    },
    {
        "Description": "In general, do not allow user-provided or otherwise untrusted data to control sensitive values. The leverage that an attacker gains by controlling these values is not always immediately obvious, but do not underestimate the creativity of the attacker.In general, do not allow user-provided or otherwise untrusted data to control sensitive values. The leverage that an attacker gains by controlling these values is not always immediately obvious, but do not underestimate the creativity of the attacker.",
        "id": "15",
        "name": "External Control of System or Configuration Setting",
        "status": "Incomplete",
        "weaknessabs": "Base"
    },
    {
        "Description": "Weaknesses in this category are typically introduced during the configuration of the software.Weaknesses in this category are typically introduced during the configuration of the software.",
        "id": "16",
        "name": "Configuration",
        "status": "Obsolete",
        "weaknessabs": "Category"
    },
    {
        "Description": "This entry has been deprecated.  It was originally used for organizing the Development View (CWE-699) and some other views, but it introduced unnecessary complexity and depth to the resulting tree.This entry has been deprecated.  It was originally used for organizing the Development View (CWE-699) and some other views, but it introduced unnecessary complexity and depth to the resulting tree.",
        "id": "17",
        "name": "DEPRECATED: Code",
        "status": "Deprecated",
        "weaknessabs": "Category"
    },
    {
        "Description": "This entry has been deprecated.  It was originally used for organizing the Development View (CWE-699) and some other views, but it introduced unnecessary complexity and depth to the resulting tree.This entry has been deprecated.  It was originally used for organizing the Development View (CWE-699) and some other views, but it introduced unnecessary complexity and depth to the resulting tree.",
        "id": "18",
        "name": "DEPRECATED: Source Code",
        "status": "Deprecated",
        "weaknessabs": "Category"
    },
    {
        "Description": "Weaknesses in this category are typically found in functionality that processes data. Data processing is the manipulation of input to retrieve or save information.Weaknesses in this category are typically found in functionality that processes data. Data processing is the manipulation of input to retrieve or save information.",
        "id": "19",
        "name": "Data Processing Errors",
        "relationships": [],
        "status": "Draft",
        "weaknessabs": "Category"
    },
    {
        "Description": "crash via multiple \".\" characters in file extensioncrash via multiple \".\" characters in file extension",
        "id": "20",
        "name": "Improper Input Validation",
        "status": "Stable",
        "weaknessabs": "Class"
    },
    {
        "Description": "This category has been deprecated. It was originally used for organizing weaknesses involving file names, which enabled access to files outside of a restricted directory (path traversal) or to perform operations on files that would otherwise be restricted (path equivalence). Consider using either the File Handling Issues category (CWE-1219) or the class Use of Incorrectly-Resolved Name or Reference (CWE-706).This category has been deprecated. It was originally used for organizing weaknesses involving file names, which enabled access to files outside of a restricted directory (path traversal) or to perform operations on files that would otherwise be restricted (path equivalence). Consider using either the File Handling Issues category (CWE-1219) or the class Use of Incorrectly-Resolved Name or Reference (CWE-706).",
        "id": "21",
        "name": "DEPRECATED: Pathname Traversal and Equivalence Errors",
        "status": "Deprecated",
        "weaknessabs": "Category"
    },
    {
        "Description": "Chain: library file sends a redirect if it is directly requested but continues to execute, allowing remote file inclusion and path traversal.Chain: library file sends a redirect if it is directly requested but continues to execute, allowing remote file inclusion and path traversal.",
        "id": "22",
        "name": "Improper Limitation of a Pathname to a Restricted Directory ('Path Traversal')",
        "status": "Stable",
        "weaknessabs": "Base"
    },
    {
        "Description": "Mail server allows remote attackers to create arbitrary directories via a \"..\" or rename arbitrary files via a \"....//\" in user supplied parameters.Mail server allows remote attackers to create arbitrary directories via a \"..\" or rename arbitrary files via a \"....//\" in user supplied parameters.",
        "id": "23",
        "name": "Relative Path Traversal",
        "status": "Draft",
        "weaknessabs": "Base"
    },
    {
        "Description": "Inputs should be decoded and canonicalized to the application's current internal representation before being validated (CWE-180). Make sure that the application does not decode the same input twice (CWE-174). Such errors could be used to bypass allowlist validation schemes by introducing dangerous inputs after they have been checked.Inputs should be decoded and canonicalized to the application's current internal representation before being validated (CWE-180). Make sure that the application does not decode the same input twice (CWE-174). Such errors could be used to bypass allowlist validation schemes by introducing dangerous inputs after they have been checked.",
        "id": "24",
        "name": "Path Traversal: '../filedir'",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Inputs should be decoded and canonicalized to the application's current internal representation before being validated (CWE-180). Make sure that the application does not decode the same input twice (CWE-174). Such errors could be used to bypass allowlist validation schemes by introducing dangerous inputs after they have been checked.Inputs should be decoded and canonicalized to the application's current internal representation before being validated (CWE-180). Make sure that the application does not decode the same input twice (CWE-174). Such errors could be used to bypass allowlist validation schemes by introducing dangerous inputs after they have been checked.",
        "id": "25",
        "name": "Path Traversal: '/../filedir'",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Inputs should be decoded and canonicalized to the application's current internal representation before being validated (CWE-180). Make sure that the application does not decode the same input twice (CWE-174). Such errors could be used to bypass allowlist validation schemes by introducing dangerous inputs after they have been checked.Inputs should be decoded and canonicalized to the application's current internal representation before being validated (CWE-180). Make sure that the application does not decode the same input twice (CWE-174). Such errors could be used to bypass allowlist validation schemes by introducing dangerous inputs after they have been checked.",
        "id": "26",
        "name": "Path Traversal: '/dir/../filename'",
        "status": "Draft",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Server allows remote attackers to cause a denial of service via certain HTTP GET requests containing a %2e%2e (encoded dot-dot), several \"/../\" sequences, or several \"../\" in a URI.Server allows remote attackers to cause a denial of service via certain HTTP GET requests containing a %2e%2e (encoded dot-dot), several \"/../\" sequences, or several \"../\" in a URI.",
        "id": "27",
        "name": "Path Traversal: 'dir/../../filename'",
        "status": "Draft",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Directory traversal vulnerability in servlet allows remote attackers to execute arbitrary commands via \"..\\\" sequences in an HTTP request.Directory traversal vulnerability in servlet allows remote attackers to execute arbitrary commands via \"..\\\" sequences in an HTTP request.",
        "id": "28",
        "name": "Path Traversal: '..\\filedir'",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Directory traversal vulnerability in FTP server allows remote authenticated attackers to list arbitrary directories via a \"\\..\" sequence in an LS command.Directory traversal vulnerability in FTP server allows remote authenticated attackers to list arbitrary directories via a \"\\..\" sequence in an LS command.",
        "id": "29",
        "name": "Path Traversal: '\\..\\filename'",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Protection mechanism checks for \"/..\" but doesn't account for Windows-specific \"\\..\" allowing read of arbitrary files.Protection mechanism checks for \"/..\" but doesn't account for Windows-specific \"\\..\" allowing read of arbitrary files.",
        "id": "30",
        "name": "Path Traversal: '\\dir\\..\\filename'",
        "status": "Draft",
        "weaknessabs": "Variant"
    },
    {
        "Description": "The administration function in Access Control Server allows remote attackers to read HTML, Java class, and image files outside the web root via a \"..\\..\" sequence in the URL to port 2002.The administration function in Access Control Server allows remote attackers to read HTML, Java class, and image files outside the web root via a \"..\\..\" sequence in the URL to port 2002.",
        "id": "31",
        "name": "Path Traversal: 'dir\\..\\..\\filename'",
        "status": "Draft",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Triple dotTriple dot",
        "id": "32",
        "name": "Path Traversal: '...' (Triple Dot)",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
    {
        "Description": "\"...\" or \"....\" in chat server\"...\" or \"....\" in chat server",
        "id": "33",
        "name": "Path Traversal: '....' (Multiple Dot)",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Mail server allows remote attackers to create arbitrary directories via a \"..\" or rename arbitrary files via a \"....//\" in user supplied parameters.Mail server allows remote attackers to create arbitrary directories via a \"..\" or rename arbitrary files via a \"....//\" in user supplied parameters.",
        "id": "34",
        "name": "Path Traversal: '....//'",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
    {
        "Description": "\".../....///\" bypasses regexp's that remove \"./\" and \"../\"\".../....///\" bypasses regexp's that remove \"./\" and \"../\"",
        "id": "35",
        "name": "Path Traversal: '.../...//'",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
    {
        "Description": "FTP server allows a remote attacker to retrieve privileged web server system information by specifying arbitrary paths in the UNC format (\\\\computername\\sharename).FTP server allows a remote attacker to retrieve privileged web server system information by specifying arbitrary paths in the UNC format (\\\\computername\\sharename).",
        "id": "36",
        "name": "Absolute Path Traversal",
        "status": "Draft",
        "weaknessabs": "Base"
    },
    {
        "Description": "Arbitrary files may be overwritten via compressed attachments that specify absolute path names for the decompressed output.Arbitrary files may be overwritten via compressed attachments that specify absolute path names for the decompressed output.",
        "id": "37",
        "name": "Path Traversal: '/absolute/pathname/here'",
        "status": "Draft",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Remote attackers can read arbitrary files via an absolute pathname.Remote attackers can read arbitrary files via an absolute pathname.",
        "id": "38",
        "name": "Path Traversal: '\\absolute\\pathname\\here'",
        "status": "Draft",
        "weaknessabs": "Variant"
    },
    {
        "Description": "FTP server read/access arbitrary files using \"C:\\\" filenamesFTP server read/access arbitrary files using \"C:\\\" filenames",
        "id": "39",
        "name": "Path Traversal: 'C:dirname'",
        "status": "Draft",
        "weaknessabs": "Variant"
    },
    {
        "Description": "FTP server allows a remote attacker to retrieve privileged web server system information by specifying arbitrary paths in the UNC format (\\\\computername\\sharename).FTP server allows a remote attacker to retrieve privileged web server system information by specifying arbitrary paths in the UNC format (\\\\computername\\sharename).",
        "id": "40",
        "name": "Path Traversal: '\\\\UNC\\share\\name\\' (Windows UNC Share)",
        "status": "Draft",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Multi-Factor Vulnerability. Product generates temporary filenames using long filenames, which become predictable in 8.3 format.Multi-Factor Vulnerability. Product generates temporary filenames using long filenames, which become predictable in 8.3 format.",
        "id": "41",
        "name": "Improper Resolution of Path Equivalence",
        "status": "Incomplete",
        "weaknessabs": "Base"
    },
    {
        "Description": "Bypass check for \".lnk\" extension using \".lnk.\"Bypass check for \".lnk\" extension using \".lnk.\"",
        "id": "42",
        "name": "Path Equivalence: 'filename.' (Trailing Dot)",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Multiple trailing dot allows directory listingMultiple trailing dot allows directory listing",
        "id": "43",
        "name": "Path Equivalence: 'filename....' (Multiple Trailing Dot)",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
    {
        "Description": "A software system that accepts path input in the form of internal dot ('file.ordir') without appropriate validation can lead to ambiguous path resolution and allow an attacker to traverse the file system to unintended locations or access arbitrary files.A software system that accepts path input in the form of internal dot ('file.ordir') without appropriate validation can lead to ambiguous path resolution and allow an attacker to traverse the file system to unintended locations or access arbitrary files.",
        "id": "44",
        "name": "Path Equivalence: 'file.name' (Internal Dot)",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
    {
        "Description": "A software system that accepts path input in the form of multiple internal dot ('file...dir') without appropriate validation can lead to ambiguous path resolution and allow an attacker to traverse the file system to unintended locations or access arbitrary files.A software system that accepts path input in the form of multiple internal dot ('file...dir') without appropriate validation can lead to ambiguous path resolution and allow an attacker to traverse the file system to unintended locations or access arbitrary files.",
        "id": "45",
        "name": "Path Equivalence: 'file...name' (Multiple Internal Dot)",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Trailing space (\"+\" in query string) leads to source code disclosure.Trailing space (\"+\" in query string) leads to source code disclosure.",
        "id": "46",
        "name": "Path Equivalence: 'filename ' (Trailing Space)",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
    {
        "Description": "A software system that accepts path input in the form of leading space (' filedir') without appropriate validation can lead to ambiguous path resolution and allow an attacker to traverse the file system to unintended locations or access arbitrary files.A software system that accepts path input in the form of leading space (' filedir') without appropriate validation can lead to ambiguous path resolution and allow an attacker to traverse the file system to unintended locations or access arbitrary files.",
        "id": "47",
        "name": "Path Equivalence: ' filename' (Leading Space)",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
    {
        "Description": "\"+\" characters in query string converted to spaces before sensitive file/extension (internal space), leading to bypass of access restrictions to the file.\"+\" characters in query string converted to spaces before sensitive file/extension (internal space), leading to bypass of access restrictions to the file.",
        "id": "48",
        "name": "Path Equivalence: 'file name' (Internal Whitespace)",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Source code disclosureSource code disclosure",
        "id": "49",
        "name": "Path Equivalence: 'filename/' (Trailing Slash)",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
    {
        "Description": "Archive extracts to arbitrary files using multiple leading slash in filenames in the archive.Archive extracts to arbitrary files using multiple leading slash in filenames in the archive.",
        "id": "50",
        "name": "Path Equivalence: '//multiple/leading/slash'",
        "status": "Incomplete",
        "weaknessabs": "Variant"
    },
]

export default data;