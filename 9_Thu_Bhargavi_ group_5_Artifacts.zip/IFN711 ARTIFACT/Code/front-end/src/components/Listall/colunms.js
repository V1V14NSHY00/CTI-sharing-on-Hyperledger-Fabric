const columns = [
    {
        title:"ID",
        dataIndex:"ID"
    },
    {
        title:"Timestamp",
        dataIndex:"Timestamp"
    },
    {
        title:"Type",
        dataIndex:"Type"
    },
    {
        title:"From",
        dataIndex:"From"
    }
]

export default columns;