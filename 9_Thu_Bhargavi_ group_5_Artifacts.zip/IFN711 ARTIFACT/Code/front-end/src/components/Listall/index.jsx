import React, { Component } from 'react'
import {Table} from 'antd'
import {Container, Card} from 'react-bootstrap'
import columns from './colunms'

export default class Listall extends Component {
  

  
  render() {
    return (
      <Container>
            {/* {
                this.props.allctis.map((userObj)=>{
                    return (
                        <Card style={{ width: '18rem' }} key={userObj.ID}>
                            <Card.Body>
                                <Card.Title>CTI ID: {userObj.ID}</Card.Title>
                                <Card.Subtitle className="mb-2 text-muted">Loc: {userObj.Loc}</Card.Subtitle>
                                <Card.Text>Targer: {userObj.Target}</Card.Text>
                                <Card.Text>Timestamp: {userObj.Timestamp}</Card.Text>
                                <Card.Text>Type: {userObj.Type}</Card.Text>
                                <Card.Text>From: {userObj.From}</Card.Text>
                            </Card.Body>
                        </Card>
                        
                    )
                })
            } */}
            <Table columns={columns} bordered dataSource={this.props.allctis}/>
      </Container>
    )
  }
}
