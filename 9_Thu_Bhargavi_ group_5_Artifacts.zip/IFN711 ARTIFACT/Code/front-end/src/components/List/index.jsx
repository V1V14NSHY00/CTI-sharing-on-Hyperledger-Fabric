import React, { Component } from 'react'
import './index.css'
const box = {
  border: '1px solid #fff',
  borderRadius: '4px',
  listStyle: 'none',
  padding: '0',
}
const liBox = {
  borderBottom: '1px solid #fff',
  display: 'flex',
  // alignItems: 'center',
  justifyContent: 'space-between',
  padding: '8px 10px',
  flexWrap: 'wrap',
}
const liBox2 = {
  display: 'flex',
  // alignItems: 'center',
  justifyContent: 'space-between',
  padding: '8px 10px',
}
const leftBox = {
  width:'80px',
  textAlign: 'right',
}
const rightBox = {
  overflow: 'hidden',
  paddingLeft: '10px',
  wordWrap: 'break-word',
  wordBreak: 'normal',
  flex:'1',
}
export default class List extends Component {
  render() {
    return (
        // <div className="row">
        //     <div key={this.props.ctis.ID} className="card">
        //         <p className="card-text">CTI ID: {this.props.ctis.ID}</p>
        //         <p className="card-text">Loc: {this.props.ctis.Loc}</p>
        //         <p className="card-text">Target: {this.props.ctis.Target}</p>
        //         <p className="card-text">Timestamp: {this.props.ctis.Timestamp}</p>
        //         <p className="card-text">Type: {this.props.ctis.Type}</p>
        //         <p className="card-text">From: {this.props.ctis.From}</p>
        //     </div>
        // </div>
      <ul key={this.props.ctis.ID} style={box}>
        <li style={liBox}><span style={leftBox}>CTI ID:</span><span style={rightBox}>{this.props.ctis.ID}</span> </li>
        <li style={liBox}><span style={leftBox}>Loc:</span><span style={rightBox}>{this.props.ctis.Loc}</span> </li>
        <li style={liBox}><span style={leftBox}>Target:</span><span style={rightBox}>{this.props.ctis.Target}</span> </li>
        {/* <li style={liBox}><span style={leftBox}>Target:</span><span style={rightBox}>this.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Targetthis.props.ctis.Target</span> </li> */}
        <li style={liBox}><span style={leftBox}>Timestamp:</span><span style={rightBox}>{this.props.ctis.Timestamp}</span> </li>
        <li style={liBox}><span style={leftBox}>Type:</span><span style={rightBox}>{this.props.ctis.Type}</span> </li>
        <li style={liBox2}><span style={leftBox}>From:</span><span style={rightBox}>{this.props.ctis.From}</span> </li>
      </ul>
    )
  }
}
