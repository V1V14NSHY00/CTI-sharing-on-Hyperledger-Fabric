import React, { Component } from 'react'
import {Link, Route, Routes} from 'react-router-dom'
import SearchCTI from './pages/searchCTI'
import AddCTI from './pages/addCTI'
import ShowAllCTI from './pages/showAllCTI'
import DeleteCTI from './pages/deleteCTI'
import ThirdPartyCTI from './pages/thirdPartyCTI'
import {Container, Row, Col} from 'react-bootstrap'
import Header from './components/Header'
import {Login} from "./pages/login/index"
import Auth from "./pages/login/auth"
// import { element } from 'prop-types'
import {Menu} from 'antd'

let  auth = new Auth();
const contentBox = {
  width:'100%',
  background: 'rgba(255,255,255,.5)'
}

export default class App extends Component {
  render() {
    return (
      <Container>
        <Row>
          <Col xs={12}>
            <Header/>
          </Col>
        </Row>
        <Row>
          <Col xs={2}>
          <Menu style={{background: 'rgba(255,255,255,.5)'}}>
            <Menu.Item key='1'><Link to="/showAllCTI">Show All CTI</Link></Menu.Item>
            <Menu.Item key='2'><Link to="/searchCTI">Search CTI</Link></Menu.Item>
            <Menu.Item key='3'><Link to="/addCTI">Add CTI</Link></Menu.Item>
            <Menu.Item key='4'><Link to="/deleteCTI">Delete CTI</Link></Menu.Item>
            <Menu.Item key='5'><Link to="/thirdPartyCTI">Third party CTI</Link></Menu.Item>
            <Menu.Item key='6'><Link to="/login">Login</Link></Menu.Item>
          </Menu>
              {/* <div className="list-group">
                <a className="list-group-item active" href="./about.html">Search CTI</a>
                <a className="list-group-item" href="./home.html">Get all CTI</a>
                <Link className="list-group-item" to="/showAllCTI">Show All CTI</Link>
                <Link className="list-group-item" to="/searchCTI">Search CTI</Link>
                <Link className="list-group-item" to="/addCTI">Add CTI</Link>
                <Link className="list-group-item" to="/deleteCTI">Delete CTI</Link>
                <Link className="list-group-item" to="/thirdPartyCTI">Third party CTI</Link>
                <Link className="list-group-item" to="/login">Login</Link>
              </div> */}
          </Col>
          <Col xs={10}>
                <div style={contentBox}>
                  <Routes>
                    <Route path="/showAllCTI" element={<ShowAllCTI/>}/>
                    <Route path="/searchCTI" element={<SearchCTI/>}/>
                    <Route className="list-group-item" exact path="/addCTI" element={<AddCTI auth={auth}/>}/>
                    <Route className="list-group-item" exact path="/deleteCTI" element={<DeleteCTI auth={auth}/>}/>
                    <Route className="list-group-item" exact path="/thirdPartyCTI" element={<ThirdPartyCTI auth={auth}/>}/>
                    {/* <Route path="/addCTI" element={<AddCTI/>}/>
                    <Route path="/deleteCTI" element={<DeleteCTI/>}/> */}
                    <Route  path="/login" element={<Login auth={auth}/>} />
                  </Routes>
                </div>
          </Col>
        </Row>
      </Container>
    )
  }
}
