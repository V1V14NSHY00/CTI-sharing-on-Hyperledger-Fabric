import React, { Component } from 'react'
import {Container, Row, Col} from 'react-bootstrap'
import Getall from '../../components/Getall'
import Listall from '../../components/Listall'
import {Card, Table} from 'antd'


export default class ShowAllCTI extends Component {
    state = {
        allctis:[],
    }
    
    saveAllCTIs = (allctis)=>{
        this.setState({allctis})
    }
    
  render() {
    return (
        // <Container>
        //     <Row>
        //         <Col>
        //             <Row>
        //                 <Getall saveAllCTIs={this.saveAllCTIs}/>
        //             </Row>
        //             <Row>
        //                 <Listall allctis={this.state.allctis}/>
        //             </Row>
        //         </Col>
        //     </Row>
        // </Container>
        <Card title='CTI Dashboard' extra={<Getall saveAllCTIs={this.saveAllCTIs}/>}>
            <Listall allctis={this.state.allctis}/>
        </Card>
    )
  }
}
