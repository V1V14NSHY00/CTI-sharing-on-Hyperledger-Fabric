import React, { Component } from 'react'
import axios from 'axios'
// import {Container, Row, Col} from 'react-bootstrap'
import { Navigate } from 'react-router-dom';
import { Divider, Button, Input } from 'antd';
const SearchBox ={
    width: '100%',
    display: 'flex',
    paddingBottom: '20px',
    alignItems: 'baseline',
    justifyContent: 'space-between',
}

export default class DeleteCTI extends Component {

    delete = () =>{
        
        axios.get(`http://localhost:3001/api/delete?id=${this.state.CTIID}`).then(
            response => {
                alert('delete success'+ response.data);
            },
            error => {console.log('fail',error);}
        )
    }

    constructor(opt) {
        super(opt);
        this.state = {
            CTIID:''
        }
    }


    handleChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    render() {

    
        if (!this.props.auth.isLogin) {
            return <Navigate to={'/login'}/>
        }

        return (
        //     <Container>
        //     <Row>Add CTI</Row>
        //     <form>
        //         <table>
        //             <tbody>
        //                 <tr>
        //                     <td><label htmlFor="txtName">Please enter CTI ID you want to delete:</label></td>
        //                     <td><input onChange={this.handleChange} type="text" di="txtCTIID" name="CTIID" value={this.state.CTIID}/></td>
        //                 </tr>
        //             </tbody>
                    
        //         </table>
        //         <button onClick={this.delete}>delete</button>
        //     </form>
        // </Container>
        <div style={{padding: '15px'}}>
            <Divider orientation="left">Delete CTI</Divider>
            <div style={SearchBox}>
                <p  style={{ color:'#333', width: '405px'}}>Please enter CTI ID you want to delete:</p>
                <Input onChange={this.handleChange} type="text" di="txtCTIID" name="CTIID" value={this.state.CTIID} style={{  marginRight: '10px'}}/>
                <Button onClick={this.delete} type="primary">delete</Button>            
            </div>
        </div>
        )
    }
}
