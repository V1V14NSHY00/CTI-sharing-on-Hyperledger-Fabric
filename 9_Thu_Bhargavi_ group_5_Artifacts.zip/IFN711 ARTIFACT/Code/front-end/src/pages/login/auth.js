import Cookies from 'universal-cookie';

export  default class Auth{
    constructor(){
        // this.isLogin = false; 
        this.cookie = new Cookies();
        this.isLogin = this.cookie.get('isLogin');
        if (!this.isLogin) {
            this.isLogin = false;
        }
    }

    
    login(user_name,user_pwd,callback){
        if (user_name==="admin" && user_pwd==="adminpw"){
            this.isLogin = true;
            this.cookie.set('isLogin', true);
            callback(); 
        }else {
            alert("login failure");
        }
    }
    
    logout() {
        this.cookie.set('isLogin', false);
        this.isLogin = false;
    }
}
