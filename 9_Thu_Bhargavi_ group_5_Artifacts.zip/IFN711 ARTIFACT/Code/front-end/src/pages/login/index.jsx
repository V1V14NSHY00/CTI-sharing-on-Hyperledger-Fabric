import React from 'react';
import Auth from "./auth";
import { useNavigate } from 'react-router-dom';
import { Button, Form, Input, Alert, Divider } from 'antd';

export function Login(prop) {
    // const [user_name, set_user_name] = useState('');
    // const [user_pwd, set_user_pwd] = useState('')
    const navigate = useNavigate();
    
      const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
      };

    if (prop.auth.isLogin) {
        return  <div style={{padding: '15px'}}>
            {/* <h3>Welcome back!</h3> */}
            <Divider orientation="left">Welcome back!</Divider>
            {/* <p><input type="submit" onClick={()=>{
                let auth = prop.auth==null ? new new Auth() : prop.auth;
                auth.logout(
                    
                    navigate(`/addCTI`)
                    
                )
            }} value="log out"/></p> */}
            <Button type="primary" style={{marginLeft:'56px'}} onClick={()=>{
                let auth = prop.auth==null ? new Auth() : prop.auth;
                auth.logout(
                    
                    navigate(`/addCTI`)
                    
                )
            }}>
                log out
                </Button>
            </div>
    }

    return <div style={{padding: '15px'}}>
        {/* <p3>Message: The access to the ledger needs to be logged in as Contributor</p3> */}
        <Alert message="Message: The access to the ledger needs to be logged in as Contributor" type="success" />
        {/* <h2>Login</h2> */}
        <Divider orientation="left">Login</Divider>
        {/* <p>
            <span>username：</span>
            <input type="text" onChange={(e)=>{
                set_user_name(e.target.value);
            }}/>
        </p>
        <p>
            <span>password：</span>
            <input type="password" onChange={(e)=>{
                set_user_pwd(e.target.value)
            }}/>
        </p>
        <p><input type="submit" onClick={()=>{
            let auth = prop.auth==null ? new new Auth() : prop.auth;
            auth.login(user_name,user_pwd,()=>{
                //  this.props.history.push("/addCTI");
                // // this.props.history.push("/deleteCTI");
                // // return 
                // <Navigate to={'/addCTI'}/>
                // window.history.push("/addCTI")
                // console.log("3231312321")
                // n('/addCTI')
                navigate(`/addCTI`);
            })
        }} value="login"/></p> */}
         <Form
            name="basic"
            labelCol={{ span: 3 }}
            wrapperCol={{ span: 16 }}
            initialValues={{ remember: true }}
            onFinish={(values)=>{
            let auth = prop.auth==null ? new Auth() : prop.auth;
            auth.login(values.user_name,values.user_pwd,()=>{
                //  this.props.history.push("/addCTI");
                // // this.props.history.push("/deleteCTI");
                // // return 
                // <Navigate to={'/addCTI'}/>
                // window.history.push("/addCTI")
                // console.log("3231312321")
                // n('/addCTI')
                navigate(`/addCTI`);
            })
            }}
            onFinishFailed={onFinishFailed}
            autoComplete="off"
            >
            <Form.Item
                label="username："
                name="user_name"
                rules={[{ required: true, message: 'Please input your username!' }]}
            >
                <Input />
            </Form.Item>

            <Form.Item
                label="password："
                name="user_pwd"
                rules={[{ required: true, message: 'Please input your password!' }]}
            >
                <Input.Password />
            </Form.Item>

            <Form.Item wrapperCol={{ offset: 3, span: 16 }}>
                <Button type="primary" htmlType="submit">
                login
                </Button>
            </Form.Item>
            </Form>
    </div>
}