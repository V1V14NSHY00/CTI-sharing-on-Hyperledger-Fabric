import React, { Component } from 'react'
// import {Container, Row, Col} from 'react-bootstrap'
import axios from 'axios'
import { Navigate } from 'react-router-dom';
import { Button, Form, Input, Divider } from 'antd';

export default class AddCTI extends Component {
    constructor(opt) {
        super(opt);
        this.state = {
            CTIID:'',
            Loc:'',
            Target:'',
            Timestamp:'',
            Type:'',
            From:''
        }
    }

    add = (values) =>{
        console.log(values)
        
        // axios.get(`http://localhost:3001/api/create?id=${this.state.CTIID}&loc=${this.state.Loc}&target=${this.state.Target}&timestamp=${this.state.Timestamp}&type=${this.state.Type}&from=${this.state.From}`).then(
        axios.get(`http://localhost:3001/api/create?id=${values.CTIID}&loc=${values.Loc}&target=${values.Target}&timestamp=${values.Timestamp}&type=${values.Type}&from=${values.From}`).then(
            response => {
                alert('add success'+ response.data);
            },
            error => {console.log('fail',error);}
        )
    }

    handleChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }
    

    render() {
        
        if (!this.props.auth.isLogin) {
            return <Navigate to={'/login'}/>
        }
        
        return (
            // <Container>
            //     <Row>Add CTI</Row>
            //     <form>
            //         <table>
            //             <tbody>
            //                 <tr>
            //                     <td><label htmlFor="txtName">CTI ID:</label></td>
            //                     <td><input onChange={this.handleChange} type="text" di="txtCTIID" name="CTIID" value={this.state.CTIID}/></td>
            //                 </tr>
            //                 <tr>
            //                     <td><label htmlFor="txtName">Loc:</label></td>
            //                     <td><input onChange={this.handleChange} type="text" di="txtLoc" name="Loc" value={this.state.Loc}/></td>
            //                 </tr>
            //                 <tr>
            //                     <td><label htmlFor="txtName">Target:</label></td>
            //                     <td><input onChange={this.handleChange} type="text" di="txtTarget" name="Target" value={this.state.Target}/></td>
            //                 </tr>
            //                 <tr>
            //                     <td><label htmlFor="txtName">Timestamp:</label></td>
            //                     <td><input onChange={this.handleChange} type="text" di="txtTimestamp" name="Timestamp" value={this.state.Timestamp}/></td>
            //                 </tr>
            //                 <tr>
            //                     <td><label htmlFor="txtName">Type:</label></td>
            //                     <td><input onChange={this.handleChange} type="text" di="txtType" name="Type" value={this.state.Type}/></td>
            //                 </tr>
            //                 <tr>
            //                     <td><label htmlFor="txtName">From:</label></td>
            //                     <td><input onChange={this.handleChange} type="text" di="txtFrom" name="From" value={this.state.From}/></td>
            //                 </tr>
                            
            //             </tbody>
                        
            //         </table>
            //         <button onClick={this.add}>Add</button>
            //     </form>
            // </Container>
             <div style={{padding: '15px'}}>
                <Divider orientation="left">Add CTI</Divider>
                <Form
                    name="basic"
                    labelCol={{ span: 3 }}
                    wrapperCol={{ span: 16 }}
                    initialValues={{ remember: true }}
                    onFinish={this.add}
                    autoComplete="off"
                    >
                    <Form.Item label="CTI ID:" name="CTIID"><Input /></Form.Item>
                    <Form.Item label="Loc:" name="Loc"><Input /></Form.Item>
                    <Form.Item label="Target:" name="Target"><Input /></Form.Item>
                    <Form.Item label="Timestamp:" name="Timestamp"><Input /></Form.Item>
                    <Form.Item label="Type:" name="Type"><Input /></Form.Item>
                    <Form.Item label="From:" name="From"><Input /></Form.Item>

                    <Form.Item wrapperCol={{ offset: 3, span: 16 }}>
                        <Button type="primary" htmlType="submit">
                        Add
                        </Button>
                    </Form.Item>
                    </Form>
             </div>
        )
    }
}
