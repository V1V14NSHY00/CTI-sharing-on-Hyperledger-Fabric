import React, { Component } from 'react'
import Search from '../../components/Search'
import List from '../../components/List'
import {Container, Row, Col} from 'react-bootstrap'


export default class SearchCTI extends Component {

    state = {
        ctis:[],
    }
    
    saveCTIs = (ctis)=>{
    this.setState({ctis})
    }

  render() {
    return (
        <Container  style={{ padding: '15px'}}>
        <Row>
          <Col>
            <Search saveCTIs={this.saveCTIs}/>
            <List ctis={this.state.ctis}/>
          </Col>
        </Row>
      </Container>
    )
  }
}
