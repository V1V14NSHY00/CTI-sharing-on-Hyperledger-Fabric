import React, { Component } from 'react'
// import axios from 'axios'
// import {Container, Row, Col} from 'react-bootstrap'
import { Navigate } from 'react-router-dom';
import GetThirdPartyData from '../../components/getThirdPartyData';
import { Divider } from 'antd';

export default class ThirdPartyCTI extends Component {

    state = {
        thirdPartyCTIs:[],
    }
    
    saveThirdPartyCTIs = (thirdPartyCTIs)=>{
        this.setState({thirdPartyCTIs})
    }



    render() {

        if (!this.props.auth.isLogin) {
            return <Navigate to={'/login'}/>
        }

        return (
            
            // <Container>
            //     <Row>
            //         <Col>
            //             <Row>
            //                 <p>CIRCL</p>
            //             </Row>
            //             <Row>
            //                 <p>cve-search is accessible via a web interface and an HTTP API. cve-search is an interface to search publicly known information from security vulnerabilities in software and hardware along with their corresponding exposures.</p>
            //             </Row>
            //             <Row>
            //                 <GetThirdPartyData saveThirdPartyCTIs={this.saveThirdPartyCTIs}/>
            //             </Row>
                        
            //         </Col>
            //     </Row>
            // </Container>
            <div style={{padding: '15px'}}>
                <Divider orientation="left">CIRCL</Divider>
                <p>cve-search is accessible via a web interface and an HTTP API. cve-search is an interface to search publicly known information from security vulnerabilities in software and hardware along with their corresponding exposures.</p>
                <GetThirdPartyData saveThirdPartyCTIs={this.saveThirdPartyCTIs}/>
            </div>
        )
    }
}
